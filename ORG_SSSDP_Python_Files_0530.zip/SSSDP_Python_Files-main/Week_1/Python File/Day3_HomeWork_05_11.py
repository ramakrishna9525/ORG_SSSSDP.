#  Find  outputs  (Home  Work)
a = [25 , 10.8 , 'Hyd' , True , 3 + 4j , None , 'Hyd' , 25]
print(a) # [25 , 10.8 , 'Hyd' , True , 3 + 4j , None , 'Hyd' , 25]
print(*a)  # 25  10.8  Hyd  True  3 + 4j  None  Hyd  25
print(type(a)) # <class 'list'>
print(id(a)) # id of a 
print(len(a)) # 8
a[2] = 'Sec' 
print(a) # [25 , 10.8 , 'Sec' , True , 3 + 4j , None , 'Hyd' , 25]
print(a[2 : 5]) # ['Sec', True, 3+4j]

# append()  and  remove()  methods  (Home  work)
a = [ ]
print(a) # []
a . append(25) 
a . append(10.8)
a . append('Hyd')
a . append(True)
print(a) # [25, 10.8, 'Hyd', True]
a . remove('Hyd')
print(a) # [25, 10.8, True]
# a . remove('25') # ERROR no str of '25' is present 
print(a) # [25, 10.8, True]

#  Find  outputs  (Home  work)
a = [25 , 10.8 , 'Hyd']
print(a) # [25 , 10.8 , 'Hyd']
print(id(a)) # id of a 
print(a * 3) # [25 , 10.8 , 'Hyd', 25 , 10.8 , 'Hyd', 25 , 10.8 , 'Hyd']
print(a * 2) # [25 , 10.8 , 'Hyd', 25 , 10.8 , 'Hyd']
print(a * 1) # [25 , 10.8 , 'Hyd']
print(a * 0) # []
print(a * -1) # []
#print(a * 4.0) # ERROR no float is allowed
a = a * 3 
print(a) # [25 , 10.8 , 'Hyd', 25 , 10.8 , 'Hyd', 25 , 10.8 , 'Hyd']
print(id(a)) # new id of a 
a = [25]
print(a , id(a)) #[25] another new id of a
#print(a * a) # ERROR only int after *

# list()  function  demo  program
a = list('Hyd')
print(a) # ['H', 'y', 'd']
print(type(a)) # <class 'list'>
print(len(a)) # 3
b = (10 , 20 , 15 , 18)
print(list(b)) # [10 , 20 , 15 , 18]
print(list(range(5))) # [0, 1, 2, 3, 4]
# print(list(25)) # Non-sequence is not allowed


'''
list()  function
-----------------
1) What  does  list(sequence)  do ?  ---> Converts  sequence  to  list

2) Is  list(non-sequence)  valid ?  ---> No  becoz  list()  function  expects  sequence  only

3) What  does  list(No-args)  do ?  ---> Returns  an  empty  list  i.e.  []

4) Finally  list()  function  does  typecasting
'''

# Find  outputs
a = [ ]
print(type(a)) # <class 'list'>
print(a) # []
print(len(a)) # 0
b = list() 
print(b) # []
print(len(b)) # 0

# Slice  demo  program (Home  work)
#        0      1     2      3      4      5        6        7
list = [25 , 10.8 , 3 + 4j , 'Hyd' , True , None , 10.8 , 'Hyd']
#       -8     -7       -6     -5     -4    -3     -2        -1
print(list[2 : 7]) #  list[2 : 7 : 1]  --->  List  from  indexes  2  to  6 in  steps  of  1  i.e.  [3 + 4j , 'Hyd' , True , None , 10.8 ]
print(list[ : : ]) #  list[0 : 8 : 1]  --->  List  from  indexes  0  to  7  in  steps  of  1  i.e.  [25 , 10.8 , 3 + 4j , 'Hyd' , True , None , 10.8 , 'Hyd']
print(list[:])  #  list[0 : 8 : 1]  --->  List  from  indexes  0  to  7  in  steps  of  1  i.e.  [25 , 10.8 , 3 + 4j , 'Hyd' , True , None , 10.8 , 'Hyd']
print(list[ : : -1]) #  list[-1 : -9 : -1]  --->  List  from  indexes  -1  to  -8  in  steps  of  1  i.e.  ['Hyd', 10.8, None, True, 'Hyd', 3+4j, 10.8, 25]
print(list[ : : 2]) #  list[-1 : -9 : 2]  --->  List  from  indexes  -1  to  -8  in  steps  of  2  i.e.  []
print(list[1 : : 2]) #  list[1 : 8 : 2]  --->  List  from  indexes  1  to  7  in  steps  of  2  i.e.  [10.8 , 'Hyd' , None , 'Hyd']
print(list[ : : -2]) #  list[-1 : -9 : -2]  --->  List  from  indexes  -1   to  -8   in  steps  of  -2  i.e. ['Hyd' , None , 'Hyd' , 10.8]
print(list[-2 : : -2]) #  list[-2 : -9 : -2]  --->  List  from  indexes  -2  to  -8  in  steps  of  1  i.e.  [10.8, 'Hyd', None, 'Hyd']
print(list[1 : 4]) #  list[1 : 4 : 1]  --->  List  from  indexes  1  to  3  in  steps  of  1  i.e.  [10.8, 3+4j, 'Hyd']
print(list[-4 : -1]) #  list[-4 : -1 : 1]  --->  List  from  indexes  -4  to  -2  in  steps  of  1  i.e.  [True , None , 10.8]
print(list[3 : -3]) #  list[3 : -3 : 1]  --->  List  from  indexes  3  to  -4  in  steps  of  1  i.e.  ['Hyd', True]
print(list[2 : -5]) #  list[2 : -5 : 1]  --->  List  from  indexes  2  to  -6  in  steps  of  1  i.e.  [3+4j]
print(list[-1:-5]) # #  list[-1 : -5 : 1]  --->  List  from  indexes  -1  to  -6  in  steps  of  1  i.e.  []

#  Find  outputs  (Home  work)
a =  [25]
# print(a[1]) # ERROR out of idex
print(a[1:]) # []

#  Tricky  program
#  Find  outputs  (Home  work)
#     0     1     2    3     4
a = [10 , 20 , 30 , 40 , 50]
print(a , id(a)) # [10 , 20 , 30 , 40 , 50] id of a
a[1 : 4] = [60 , 70]
print(a , id(a)) # [10, 60, 70, 50] same id of a 
a[2: 4] = [100 , 200 ,  300]
print(a , id(a)) # [10, 60, 100, 200, 300] same id of a

# List  packing
a = 25
b = 10.8
c = 'Hyd'
d = True
e = [a , b , c , d] 
print(e) # [25, 10.8, 'Hyd', True]
print(type(e)) # <class 'list'>

# List  unpacking
list = [25 , 10.8 , 'Hyd' , True]
a , b , c , d = list
print('a : ' , a)  # 25
print('b : ' , b)  # 10.8
print('c : ' , c)  # Hyd
print('d : ' , d)  # True
# x , y , z = *list  # ERROR no need of *
# x , y , z = list  # ERROR too many values(expected 3, got 4)
# a , b , c , d , e = list # not enough values(expected 5, got 4)

#  Find  outputs  (Home  work)
#        0       1      2          3         4        5         6        7
list = [25 , 10.8 , 3+4j , 'Hyd' , True , None , 10.8 , 'Hyd']
x ,  y = list[3 : 5]
print('x : ' , x) # Hyd
print('y : ' , y) # True
for  x  in  list[2 : 7]:
	print(x) # 3+4j\n Hyd\n True\n None\n 10.8

#  Find  outputs  (Home  work)
a = (25 , 10.8 , 'Hyd' , True , 3+4j , None , 'Hyd' , 25)
print(a) # (25 , 10.8 , 'Hyd' , True , 3+4j , None , 'Hyd' , 25)
print(*a) # 25 10.8 Hyd True 3+4j None Hyd 25
print(type(a)) # <class 'tuple'>
print(len(a)) # 8
print(a[2 : 5]) # ('Hyd', True, 3+4j)
print(*a[2 : 5]) # Hyd True 3+4j
#a[2] = 'Sec' # ERROR tuple is immuable
#a . remove('Hyd') # ERROR tuple is immuable
a =  10 , 20 , 30
print(a) # (10, 20, 30)
print(a * 2) # (10, 20, 30, 10, 20, 30)
a = 40 , 50 , 60,
print(a) # (40, 50, 60)
print(type(a)) # <class 'tuple'>

# Find  outputs  (Home  work)
a = (25)
b = 25,
c = 25
d = (25,)
print(type(a)) # <class 'int'>
print(type(b)) # <class 'tuple'>
print(type(c)) # <class 'int'>
print(type(d)) # <class 'tuple'>
print(a * 4) # 100
print(b * 4) # (25, 25, 25, 25)
print(c * 4) # 100
print(d * 4) # (25, 25, 25, 25)

# tuple()  function  demo  program  (Home  work)
a = tuple('Hyd')
print(a) # ('H', 'y', 'd')
print(type(a)) # <class 'tuple'>
print(len(a)) #3
b = [10 , 20 , 15 , 18]
print(tuple(b)) # (10, 20, 15, 18)
print(tuple(range(5))) # (0, 1, 2, 3, 4)
# print(tuple(25)) # ERROR due to Non-sequence is not allowed


'''
tuple()  function
-------------------
1) What  does  tuple(sequence)  do ?  --->  Converts  sequence  to  tuple

2) Is  tuple(non-sequence)  valid ?  --->  No  becoz  tuple()  function  expects  sequence

3) What  does  tuple(No-args)  do ?  --->  Returns  an  empty  tuple
'''

# Find  outputs (Home  work)
a = ()
print(type(a)) # <class 'tuple'>
print(a) # ()
print(len(a)) # 0
b = tuple()  
print(b) # ()
print(len(b)) # 0

# Tricky program
# Find  outputs (Home  work)
a = (10 , 20 , 30)
print(a) # (10, 20, 30)
print(id(a)) # id of a
a = a * 2  #  Valid / Invalid
print(a) # (10, 20, 30, 10, 20, 30)
print(id(a)) # new id of a 

# Find  outputs   (Home  work)
a = 25
b = 10.8
c = 'Hyd'
d = True
x = a , b , c , d
print(x) # (25, 10.8, 'Hyd', True)
print(type(x)) # <class 'tuple'>

# Find  outputs   (Home  work)
tpl = 25 , 10.8 , 'Hyd' , True
a , b , c , d = tpl
print(a) # 25
print(b) # 10.8
print(c) # Hyd
print(d) # True 
#p , q , r , s = *tpl # star is no needed 
#x , y , z = tpl # too many values(expected 3, got 4)
#m , n , o , p , r = tpl # ERROR not enough values(expected 5, got 4)

#  set  object  demo  program  (Home  work)
a = {25 , 10.8 , 'Hyd' , True , 3+4j , None , 25 , 'Hyd'}
print(a) # {25, 10.8, 'Hyd', True, 3+4j, None}
print(type(a)) # <class 'set'>
print(len(a)) # 6
#print(a[2]) # ERROR set has no indexes
#print(a[1 : 4]) # ERROR set has no indexes
#a[2] = 'Sec' # ERROR Set has no assignmets with indeces
#print(a * 2) # ERROR set can't have duplocate values
#print(a * a) # ERROR set cannot repeat with set

# Tricky  program
# Find  outputs (Home  work)
a = {1 , 'Hyd' , False , True , 0.0 , '' , 1.0 ,  0}
print(a) # {1, 'Hyd', False, ''}
print(len(a)) # 4
print(type(a)) # <class 'set'>

#  set()  function demo  program
a = set('Rama rAo')
print(a) # {'R', 'a', m',' ','r','A','o'} 
print(len(a)) # 7
print(set([10 , 20 , 15 , 20])) # {10, 20, 15}
print(set((25 , 10.8 , 'Hyd' , 10.8))) # {25, 10.8, 'Hyd'}
print(set(range(10 , 20 , 3))) # {10, 13, 16, 19}
#print(set(25)) # ERROR non- sequence not allowed
#print(set([25 , 10.8 , [] , 'Hyd'])) # ERROR no mutable elemnets is allowed in set


'''
set()  function
-----------------
1) What  does  set(sequence)  do ?  --->  Converts  sequence  to  set

2) Is  set(non-sequence)  valid ?  ---> No  becoz  set()  function  expects  sequence

3) What  does  set(No-args)  do ?  --->  Returns  an  empty  set
'''

# Find  outputs  (Home  work)
a =   [ ]
b =   ( )
c =   {}
d =   set()
print(type(a)) # <class 'list'>
print(type(b)) # <class 'tuple'>
print(type(c)) # <class 'dict'>
print(type(d)) # <class 'set'>
print(a) # []
print(b) # ()
print(c) # {}
print(d) # set()

# Tricky  program
# add()  and  remove()  methods  (Home  work)
a = set()
a . add(25)
a . add(10.8)
a . add('Hyd')
a . add(True)
a . add(None)
a . add('Hyd')
a . add(1)
print(a) # {25, 10.8, 'Hyd', True, None}
print(len(a)) # 5
a . remove(25) # {10.8, 'Hyd', True, None}
print(a) # {25, 10.8, 'Hyd', True, None}
# a . append(100) # ERROR set has no method append
# a . add(set()) # ERROR set doesn't contain mutable elemnets 
a . add(()) # {10.8, 'Hyd', True, None, ()}
#a . add([]) # ERROR set doesn't contain mutable elemnets 
print(a) # {10.8, 'Hyd', True, None, ()}
#a . add({}) # ERROR set doesn't contain mutable elemnets 

# How  to  print  set  in  two  differnet ways  (Home  work)
a = {25 , True , 'Hyd' , 10.8}
print('set  with  print  function')
print(a)
print('Iterate  thru  set  with  for  loop')
# How  to  iterate  thru  set  with  for  loop
for i in a:
    print(x)

#  Find  outputs
print((32 , 40.6 , [39 , 54.8] , 'Hyd')) # valid (32 , 40.6 , [39 , 54.8] , 'Hyd')
#print({(32 , 40.6 , [39 , 54.8] , 'Hyd')}) # Not valid it contains list in tuple and tuple in set

# Find  outputs  (Home  work)
a = 'Hyd'
b = True
c = 25
d = 1
e = 'Hyd'
s = {a , b , c , d , e}
print(s) # {'Hyd', True, 25}
print(len(s)) # 3
print(type(s)) # <class 'set'>

# Find  outputs  (Home  work)
s = {'Hyd',  25,  True,  10.8 }
print(s) # {'Hyd',  25,  True,  10.8 }
a , b , c , d = s
print(a) # 'Hyd'
print(b) # True
print(c) # 10.8
print(d) # 25

# Find  outputs  (Home  work)
a = {10 : 'Ramesh' , 20 : 'Kiran' , 15 : 'Amar' , 18 : 'Sita'}
print(a) # {10 : 'Ramesh' , 20 : 'Kiran' , 15 : 'Amar' , 18 : 'Sita'}
print(type(a)) # <class 'dict'>
print('How  to  print  value  key  10:', a[10])
print('How  to  print  value  key  20:',a[20])
print('How  to  print  value  key  15:', a[15])
print('How  to  print  value  key  18:',a[18])
#print(a[19]) # ERROR no key of 19
#print(a[0]) # ERROR no key of 0
#print(a['Amar']) # ERROR only keys are allowed
'''How  to  moify  value  of   key  15  to  'Krishna'
How  to  remove  20 :  'Kiran'  from  dict  'a'
How  to  append  25 : 'Vamsi'  to  dict  'a' '''
a[15] = 'Krishna'
del a[20]
a[25] = 'Vamsi'
print(a) # {10 : 'Ramesh' , 15 : 'Krishna' , 18 : 'Sita', 25 : 'Vamsi'}
print(len(a)) # 4
#print(a * 2) # ERROR no repetiton for dict, duplicates not allowed

# Find  outputs  (Home  work)
a = {10 : 'Hyd' , 10 : 'Sec'}
print(a) # {10 : 'Sec'}
print(len(a)) # 1
b = {'R' : 'Red' , 'G' : 'Green' , 'B' : 'Blue' , 'Y' : 'Yellow' , 'G' : 'Gray' , 'B' : 'Black'}
print(b) # {'R' : 'Red', 'G' : 'Gray', 'B' : 'Black', 'Y' : 'Yelllow'}
print(len(b)) # 4

#  Tricky  program
# Find output  (Home  work)
a = {True : 'Yes' , 1 : 'No' , 1.0 : 'May  be'}
print(a) # {True : 'May be'}
print(len(a)) # 1

# Find  outputs
#a = { [ ] : 25} # ERROR keys not should be mutable elemnets 
b = { ( ) : 25} 
print(b) # {() : 25}
#c = { { } : 25} # ERROR keys not should be mutable elemnets 
d = {'Ramesh' : [9948250500, 9848565090, 9440250404]}
print(d) # {'Ramesh' : [9948250500, 9848565090, 9440250404]}
print(len(d)) # 1
#e = {set() : 10.8} # ERROR keys not should be mutable elemnets 

# Find  outputs
a = {}
print(type(a)) # <class 'dict'>
print(len(a)) # 0
print(a) # {}
b = dict()
print(type(b)) # <class 'dict'>
print(len(b)) # 0
print(b) # {}

# How  to  print  dictionary  in  different  ways
a  =  {10 : 'Ramesh' ,  20 : 'Kiran' , 15 : 'Amar' , 18 : 'Sita'}
print('Dictionary  with  print  function')
#How  to  print  dictionary  with  print()  function
print(a)
print('Keys  of  dictionary')
#How  to  iterate  thru  each  key  of  dict  'a'  with  for  loop
for i in a.keys():
    print(i)
print('Values  of  dictionary')
#How  to  iterate  thru  each  value  of  dict  'a'  with  for  loop
for i in a.values():
    print(i)
print('Tuples  of  dict_items   object')
#How  to  iterate  thru  each  tuple  of  dict  'a'  with  for  loop
for i in a.items():
    print(i)
print('Elements  of  each   tuple')
#How  to  print  elements  of  each  tuple  in  the  list  of  dict_items  object
for i in a.items():
    print(*i, sep='..')
for i in a.items():
    print(i[0], i[1])
print('Keys  and  values  of  dictionary')
#How  to  print  each  key  and  corresponding  value  in  dict  'a'
for i, j in a.items():
    print(i,j, sep=':')