# Find  outputs (Home  work)
a = 0O6247
print(a) # 3239
print(type(a)) # <class 'int'>
print(id(a))  # id of a
b = 0o6247
print(id(b)) # same id of a as before 
print(b) # 3239
c = 3239
print(c) # 3239
print(id(c)) # same id of a as before 
# print(0o9248) # ERROR because octal can't contain 9 and 8 

# Find  outputs  (Home  work)
a = 0XA7B9
print(a) # 42937
print(type(a)) # <class 'int'>
b = 0xBEEF 
print(b) # 48879
#print(A7B9)  # ERROR  no A7B9 is defined
print('A7B9') # A7B9
# print(0XBEER) # ERROR Hexa-Decimal doesn't contain R 
#print(0XHYD) # ERROR Hexa-Decimal can't contain H and Y
#print(0xA7G9B) # ERROR Hexa-Decimal can't contain G

# Find outputs (Home  work)
a = 9248
print(a) # 9248
print(type(a)) # <class 'int'>

#  Find  outputs  (Home  work)
a = "Rama Rao"
print(a) # Rama Rao
print(type(a)) # <class 'str'>
print(id(a)) # id of a 
b = 'Hyd' 
print(b) # Hyd
c = '''Hyd is green city.
Hyd is hitec city.
Hyd is beautiful city.'''
print(c)
"""Hyd is green city.
Hyd is hitec city.
Hyd is beautiful city."""

# Index   demo  program  (Home  work)
a = 'Hyd'
print("How  to  print  'H'  of  object  'a':", a[0])
print("How  to  print  'y'  of  object  'a':",a[1])
print("How  to  print  'd'  of  object  'a':", a[2])
# print(a[3]) # ERROR becoz out of range
print("How  to  print  'd'  of  object  'a':", a[-1])
print("How  to  print  'y'  of  object  'a':",a[-2])
print("How  to  print  'H'  of  object  'a':",a[-3])
#print(a[-4])  # ERROR due to out of index
# print(a[0] ==  a[-3]) #  ERROR due to str is mutable
#a[2] = 'c' # ERROR due to str is mutable
#print(25[0]) # ERRO due to 25 is non-sequence
print('25'[0]) # 2
# print(True[1]) # ERRO due to True is non-sequence
print('True'[1]) # r

#  Find  outputs  (Home work)
a = 'Hyd'
print(a * 3) # HydHydHyd
print(a * 2) # HydHyd
print(a * 1) # Hyd
print(a * 0) # empty
print(a * -1) # empty
print(25 * 3) # 75
print('25' * 3) # 252525
# print('25' * 4.0) # ERROR only int allowed after *
print(3 * 'Hyd') # HydHydHyd
print('25' * True) # 25

'''
Tricky  program

Find  outputs  (Home work)
'''
a = 'Hyd'
print(a , id(a)) # Hyd id of a
a = a * 3  #  Is  it  valid ---> Yes it is valid becoz a points to new obkect 
print(a , id(a)) # HydHydHyd new id of a 

# len()  function  (Home  work)
print(len('Hyd')) # 3
print(len('Rama Rao')) # 8
print(len('9247')) # 4
print(len('')) # 0
print(len(' ')) # 1
# print(len(689)) # ERROR cause it is a non-sequence

# Find  outputs  (Home  work)
a = """"Hyd""" 
print(a) # "Hyd
print(len(a)) # 4
print(a[0]) # "
# print("""Hyd"""") # ERROR cause quotes are allowed at beginning not at last
b = """""Hyd"""
print(b) # ""Hyd
print(len(b)) # 5

# Find  outputs
a = 'Sankar Dayal Sarma'
print(a[7 : 12]) #  a[7 : 12 : 1]  --->  String  from  indexes  7  to  11  in  steps  of  1  i.e. Dayal
print(a[7 : ]) #  a[7 : 18 : 1]  --->  String  from  indexes  7  to  18  in  steps  of  1  i.e. Dayal Sarma
print(a[ : 6]) #  a[0 : 6 : 1]  --->  String  from  indexes  0  to  5  in  steps  of  1  i.e. Sankar
print(a[ : ])  #  a[0 : 18 : 1]  --->  String  from  indexes  0  to  17  in  steps  of  1  i.e. Sankar Dayal Sarma
print(a[:  : ]) #  a[0 : 18 : 1]  --->  String  from  indexes  0  to  17  in  steps  of  1  i.e. Sankar Dayal Sarm
print(a[1 : 10 : 2]) #  a[1 : 10 : ]  --->  String  from  indexes  1  to  9  in  steps  of  2  i.e. akrDy
print(a[0 : : 2]) #  a[0 : 18 : 2]  --->  String  from  indexes  0  to  17  in  steps  of  2  i.e. Sna aa am
print(a[1 : : 2]) #  a[1 : 18 : 2]  --->  String  from  indexes  1  to  17  in  steps  of  2  i.e. akrDylSra
print(a[-5 : -1]) #  a[-5 : -1 : 1]  --->  String  from  indexes  -5  to  -2  in  steps  of  1  i.e. Sarm
print(a[::-1]) #  a[-1 : -19 : -1]  --->  String  from  indexes  -1  to  -18  in  steps  of  1  i.e. amraS layaD raknaS
print(a[-1:-5:-1]) #  a[-1 : -5 : -1]  --->  String  from  indexes  0  to  17  in  steps  of  1  i.e. Sankar Dayal Sarm
print(a[ : : -2]) #  a[-1 : -19 : -2]  --->  String  from  indexes  -1  to   -18  in  steps  of  -2   i.e. arSlyDrka
print(a[3 : -3]) #  a[3 : -3 : 1]  --->  String  from  indexes  3  to  -4  in  steps  of  1  i.e. empty
print(a[2 : -5]) #  a[2 : -5 : 1]  --->  String  from  indexes  2  to  -6  in  steps  of  1  i.e. empty
print(a[-1:-5]) #  a[-1 : -5 : 1]  --->  String  from  indexes  -1  to  -6  in  steps  of  1  i.e. empty
print(a[3 : 3]) #  a[3 : 3 : 1]  --->  String  from  indexes  3  to  2  in  steps  of  1  i.e. empty


#   0      1      2      3      4       5       6           7       8       9     10     11     12           13     14       15      16     17
#   S      a      n      k      a       r                    D       a       y      a       l                     S       a         r       m       a
#  -18   -17   -16   -15    -14   -13    -12        -11     -10    -9     -8    -7      -6          -5      -4       -3      -2      -1

#  Find  outputs  (Home  work)
a =  'A'
# print(a[1]) # ERROR out of range
print(a[1:]) # empty

# int()  function  demo  program
print(int(10.8))  #   10
print(int(True))  #  1
print(int(False)) # 0
print(int('25')) # 25
print(int('0075')) # 75
print(int(0B11010)) # 26
print(0B11010) # 26
print(int(0O6247)) # 3239
print(0O6247) # 3239
print(int(0XA7B9)) # 42937
print(0XA7B9) # 42937
#print(int(3 + 4j)) # ERROR complex can't convert to int
#print(int('25.4')) # ERROR str float can't convert to int
#print(int('Ten')) # ERROR string can't convert to int


'''
int()  function
----------------
1) What  does  int(x)  do  ?  --->  Converts  object  'x'  to  integer
'''

# float()  function  demo  program
print(float(25))  #  25.0
print(float(True)) # 1.0
print(float(False)) # 0.0
print(float('92')) # 92.0
print(float('36.4'))  #36.4
print(float('0075'))  #  75.0
print(float(0B1010101)) # 85.0
print(float(0O6247)) # 3239.0
print(float(0XA7B9)) # 42937.0
#print(float(3 + 4j)) # ERROR complex can't convert to float
#print(float('Ten')) # ERROR str Ten can't convert to float



'''
float()   function
--------------------
1) What  does  float(x)  do  ?  ---> Converts  object  'x'  to  float
'''

# complex()  function  demo  program
print(complex(3 , 4)) # (3+4j)
print(complex(0 , 4)) # 4j
print(complex(3)) # (3+0j)
print(complex(3.8 , 4.6)) # (3.8+4.6j)
print(complex(3.8)) # (3.8+0j)
print(complex(3 , 4.5)) # (3+4.5j)
print(complex(True , False)) # (1+0j)
print(complex(True)) # (1+0j)
print(complex(False)) # 0j
print(complex(True , 4)) # (1+4j)
print(complex('3')) # (3+0j)
print(complex('3.8')) # (3.8+0j)
#print(complex(3 , '4'))  # ERROR due to 2nd element can't be str
#print(complex('3' , 4))  # ERROR becoz while 1st is already str then 2nd don't needed
#print(complex('3' , '4')) # ERROR becoz when 1st is str 2nd not needed
#print(complex('Ten')) # str Ten can't convert to complex

#  bool()  function  demo  program
print(bool(0)) # False
print(bool(10))  # True
print(bool(-25)) # True
print(bool(0.0)) # False
print(bool(0.1))  #  True
print(bool(0 + 0j)) # False
print(bool(10 + 20j)) # True
print(bool(-15j)) # True
print(bool('False'))  #  True
print(bool('')) # False 
print(bool('Hyd')) # True
print(bool(' ')) #True
print(bool('True')) # True



'''
bool()  function
------------------
1) What  does  bool(x)  do  ?  ---> Converts  object  'x'  to  True / False

2) Is  0  True  (or)  False ? ---> False
    What  about  non-zero ?  ---> True

3) Is  ''(i.e.  Empty  string)  True  (or) False ?  ---> False
    What  about  non-empty  string ?  --->	 True

4) When  is  x + yj  treated  as  False ?  ---> When  both  'x'  and  'y'  are  zeroes
     When  is  x + yj  treated  as  True ?  --->  When  either  'x'  is   non-zero  (or)  'y'  is  non-zero
'''

# str()  function  demo  program
print(str(25))    #  '25'
print(str(10.8)) # 10.8
print(str(3 + 4j)) # 3+4j
print(str(True)) # True
print(str(False)) # False
print(str(None)) # None


'''
str()  function
-----------------
What  does  str(x)  do ?  ---> Converts  object  'x'  to  string
'''

# oct()  function  demo  program
print(oct(195))  # 0o303
print(oct(0B10101110010)) # 0o2562  
print(oct(0xA7B9)) # 0o 123671







'''
oct()  function
-----------------
1) What  does  oct(x)  do ?  --->  Converts  object  'x'  to  octal  number  where
								                    'x'  can  be  binary / decimal / hexa-decimal  number
                                                    '''

# hex()  function  demo  program
print(hex(25))  # 0x19
print(hex(0B10101111010111)) # ox2bd7 
print(hex(0O6247))  #0xca7








'''
hex()  function
------------------
1) What  does  hex(x)  do ?  --->  Converts  object  'x'  to  hexa-decimal  number  where
								                     'x'  can  be  binary / decimal / octal  number'''

# Find  outputs    (Home  work)
a = range(10 , 50 , 5) 
print(type(a)) # <class 'range'>
print(a) # range(10, 50, 5)
print(*a) # 10, 15, 20, 25, 30, 35, 40, 45
print(id(a)) # id of a 
print(len(a)) # 8
print(*a[2 : 7] , sep = ' , ') # 20 25 30 35 40
print(*a[ : : -1]) # 45 40 35 30 25 20 15 10
# a[4] = 32 # ERROR range is immutable
#print(a * 2) # range can't have duplicates 

#  Find  outputs  (Home  work)
a = range(10 , 20)
print(*a , sep = ',') # 10,11,12,13,14,15,16,17,18,19
b = range(5)
print(*b) # 0 1 2 3 4 
c = range(10 , 1 , -1)
print(*c , sep = '...') # 10...9...8...7...6...5...4...3...2
d = range(-10 , 0)
print(*d) # -10 -9 -8 -7 -6 -6 -5 -4 -3 -2 -1
e = range(-10)
print(*e) # empty
f = range(2 , 2)
print(*f) # empty
# g = range(10 , 11 , 0.1) # Range can't have float elements
# h = range('A' , 'F') # range can have only int elements

#  Find  outputs  (Home  work)
r = range(10 ,  17 , 3)
a , b , c = r  # 10 , 13, 16
print(a , b , c) # 10 13 16
r = range(3)   
# x , y = r  # too many values to unpack(expected 2, got 3) 
# p , q  , r , s = r # insufficient values to unpack(expected 4, got 3) 
# a , b , c = *r  # * is not needed
m = r  
print(id(r)) # id of r
print(id(m)) # same id as r