# float  object  demo  program (Home  work)
a = 10.8
print(a) # 10.8
print(type(a)) # <class 'float'>
print(id(a)) # id of a 
a = 25.
print(a) # 25.0
print(type(a)) # <class 'float'>
a = .689 
print(a) # 0.689
a = 3.4E2 
print(a) # 3.4 * 10 ^ 2 
print(type(a)) # <class 'float'>
a = 9.62e-2
print(a) # 9.62 * 10 ^ -2
# print(9.8.2) # ERROR becoz two decimal points 

# complex object demo program
a = 3 + 4j
print(a) # (3 + 4j)
print(type(a)) # <class 'complex'>
print(id(a)) # id of a 
print(a . real) # 3.0
print(a . imag) # 4.0
print(type(a . real)) # <class 'float'>
print(type(a . imag)) # <class 'float'>

# Find outputs (Home work)
a = 6j
print(a) # 6j
print(type(a)) # <class 'complex'>
print(a . real) # 0.0
print(a . imag) # 6.0
#print(5 + j6)  # ERROR becoz j before 6
#print(3 + 4i) # ERROR becoz i not allowed 
#print(4 + j) # ERROR becoz no value specified at j
print(4 + 1j) # (4 + 1j)
print(4 + 0j) # (4 + 0j)

# bool object demo program  (Home  work)
a = True
print(a) # True
print(type(a)) # <class 'bool'>
print(id(a)) # id of a
a = False 
print(a) # False
print(type(a)) # <class 'bool'>
print(True + True) # 2
print(True + False) # 1
print(False + True) # 1
print(False + False) # 0
print(True + True + True) # 3
print(25 + 10.8 + True) # 36.8
print(True > False)  # True
print(True) # True
print(False) # False
#print(true) # ERROR true is not defined
#print(false) # ERROR false is not defined