#  Find  outputs (Home  work)
a = {
		print('Hyd') ,
		print('Sec') , 
		print('Cyb')   
     }  # Hyd <> Sec <> Cyb
print(type(a)) # <class 'set'>
print(a)  # {None}
print(len(a)) # 1

#  Anonymous  object  demo  program
_ = 25 
print(_) # 25
print(type(_)) # <class 'int'> 
print(id(_)) # id of _
a , _ , c = 10 , 20 , 30  
print(a) # 10
print(_) # 20
print(c) # 30
for  _  in  range(5):
	print(_ , 'Hello') # 0 Hello <> 1 Hello <> 2 Hello <> 3 Hello <> 4 Hello

#  Find  outputs
a = 25
print(a , id(a)) # 25 id of a 
a = 35
print(a , id(a)) # 35 new id of a

# Find  outputs (Home  work)
a = 25.7
print(a , id(a)) # 25.7 id of a 
a = 35.6 
print(a , id(a)) # 35.6 new id of a 
b = True
print(b , id(b)) # True id of a
b = False
print(b , id(b)) # False new id of a
c = None
print(c , id(c)) # None id of c
c = None
print(c , id(c)) # None same id of c

# Find  outputs  (Home  work)
a = 'Hyd' 
print(a , id(a)) # Hyd id of a
#a[1] = 'e' # ERROR str is immutable
a = 'Sec'  
print(a , id(a))  # Sec new id of a
b = (10 , 20 , 15 , 18) 
print(b , id(b)) # (10, 20, 15, 18) id of b
#b[2] = 19 # ERROR tuple is immutable
b = (30 , 40 , 35 , 32) 
print(b , id(b))  # (30, 40, 35, 32) new id b
c = range(5)  
print(id(c))  # id of c
#c[3] = 10 # ERROR range is immutable
c = range(5) 
print(id(c)) # new id of c

# Find  outputs  (Home  work)
a = 25 
b = 25  
print(a  is  b) # True
c = 'Hyd'  
d = 'Hyd'  
print(c  is  d)  # True
e = False   
f = False   
print(e  is  f) # True
g = range(10) 
h = range(10) 
print(g  is  h) # False

# Find  outputs(Home  work)
a = [10 , 20 , 15 , 18]
b = [10 , 20 , 15 , 18]
print(a  is  b) # False
c =  {10 : 20, 30 : 40}
d =  {10 : 20, 30 : 40}
print(c  is  d) # False
e = (10 , 20 , 15 , 18)
f = (10 , 20 , 15 , 18)
print(e  is  f) # True
g = {10 , 20 , 15 , 18}
h = {10 , 20 , 15 , 18}
print(g  is  h) # False

# Find outputs (Home work)
print(10 + 20) # 30
print(10.8 + 20.6) # 31.4
print(3 + 4j + 5 + 6j) # 8 + 10j
print(True + False) # 1
print('Hyder' + 'abad') # Hyderabad 
print('Sankar' + 'Dayal' + 'Sarma') # SankarDayalSarma 
print('10' + '20') # 1020
print([10 , 20 , 30] + [1 , 2 , 3]) # [10,20,30,1,2,3]
print((25 , 10.8 , 'Hyd') + (3 + 4j , True , None)) # (25,10.8,'Hyd',3+4j,True,None)
#print({10 , 20} + {30 , 40}) # ERROR set cannot multiply with set
#print({10 : 'Hyd'} + {20 : 'Sec'})  # ERROR dict can't added
#print(range(4) + range(5)) # ERROR range cannot have duplicate values
#print(10 + '20') # ERROR sequence and non-sequence added
#print([10 , 20 , 30] + 5) # ERROR list and non-sequence not addded
#print([10 , 20 , 30] + (40 , 50 , 60)) # ERROR same type sequence needed

# Find outputs (Home work)
print(25 * 3) # 75
print(10.8 * 25.6) # 276.48
print(True * False) # 0
print((3 + 4j) * (5 + 6j)) # -9+38j
print(3 + 4j * 5 + 6j) # 3+26j
print('25' * 3) # 252525
print(3 * '25') # 252525
print('Hyd' * 4) # HydHydHydHyd
print([10 , 20 , 15] * 2) # [10,20,15,10,20,15]
print((25, 10.8, 'Hyd', True) * 3) # (25, 10.8, 'Hyd', True, 25, 10.8, 'Hyd', True, 25, 10.8, 'Hyd', True)
#print([10 , 20 , 15] * 3.0) #ERROR no float is allowed
#print({10 , 20 , 15} * 2) # Set can't be repeated
#print({10 : 20 , 30 : 40} * 2) # ERROR dict can't be repeated
#print([10] * [20]) # # ERROR list and list not supported

#  /  operator  demo  program
print(9.0 / 2)  #  4.5
print(9 / 2.0) # 4.5
print(9.0 / 2.0) # 4.5
print(9 / 2)  #  4.5
print(10.5 / 2) # 5.25
print(10 / 3) # 3.33
print(10 / 2) # 5.0


'''
What  does  /  operator  do  ?  ---> Peforms  division   and  returns  float  quotient
'''

# //  operator  demo  program
print(9 // 2)  #   prev(4.5) = 4
print(9.0 // 2)  #  prev(4.5) = 4.0
print(9 // 2.0)  #  prev(4.5) = 4.0
print(9.0 // 2.0) # 4.0
print(10.5 // 2) # 5.0
print(10 // 3) # 3
print(10.0 // 3) # 3.0
print(8.5 // 3) # 2.0
print(18 // 4) # 4
print(-18 // 4) # -5
print(-(18 // 4)) # -4


'''
//  operator
--------------
1) What  is  the  result  of  integer // integer ?  ---> Integer  quotient
    What  is  the  result  of  integer // float ?  --->  Float  quotient  with  .0
    What  is  the  result  of  float // integer ?  ---> 	Float  quotient  with  .0
    What  is  the  result  of  float // float ?  ---> Float  quotient  with  .0

2) What  is  the  result  of  integer / integer ?  ---> Float  quotient
    What  is  the  result  of  integer / float ?  ---> Float  quotient
    What  is  the  result  of  float / integer ?  ---> Float  quotient
    What  is  the  result  of  float / float ?  ---> Float  quotient

3) What  does  /  operator  do ?  ---> Performs  division  and  returns  float  quotient
     What  does  //  operator do ?  ---> Same  as  /  operator  except  that  it  returns  previous-integer(/  operator)

4) When  is  the  result  of  //  operator  integer ?  ---> When  both  the  operands  are  integers
    When  is  the  result  of   //  operator  float  with  .0 ?  ---> When  at  least  one  operand  is  float
'''

# Find outputs
#print(7 / 0) # ERROR no zero division
#print(7 // 0) # ERROR no zero division
#print(7 % 0) # ERROR no zero division

# ** operator demo program
print(3 ** 4) # 81
print(10 ** -2) # 0.001
print(4 ** 3 ** 2) # 262144
print(3 + 4 * 5 - 32 / 2 ** 3) # 19.0



'''
**  operator
---------------
1) What  is  **  operator  called ?  ---> Power  operator

2) What  is  the  result  of  a ** b ?  ---> a ^ b

3) What  is  the  result  of  a ** b  ** c ?   --->  a ^ b ^ c

4) What  is  the  associativity  of  **  operator ?  ---> Right  to  left
    What  is  the  associativity  of  remaining  arithmetic  operators ?  ---> Left  to  right
    '''